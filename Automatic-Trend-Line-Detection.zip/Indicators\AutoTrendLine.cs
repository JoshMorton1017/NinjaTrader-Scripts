#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
using NinjaTrader.NinjaScript.DrawingTools;
#endregion

//This namespace holds Indicators in this folder and is required. Do not change it. 
namespace NinjaTrader.NinjaScript.Indicators
{
	public class AutoTrendLine : Indicator
	{
		private int triggerBarIndex = 0;
		private int signal;

		protected override void OnStateChange()
		{
			if (State == State.SetDefaults)
			{
				Description = @"Automatically draws a line representing the current trend and generates an alert if the trend line is broken.";
				Name = "AutoTrendLine";
				Calculate = Calculate.OnBarClose;
				IsOverlay = true;
				DisplayInDataBox = false;
				DrawOnPricePanel = true;
				DrawHorizontalGridLines = true;
				DrawVerticalGridLines = true;
				PaintPriceMarkers = true;
				ScaleJustification = NinjaTrader.Gui.Chart.ScaleJustification.Right;
				//Disable this property if your indicator requires custom values that cumulate with each new market data event. 
				//See Help Guide for additional information.
				IsSuspendedWhileInactive = true;
				AlertOnBreak = true;
				Strength = 5;
				LineWidth = 1;
				signal = 1;
				DownTrendColor = Brushes.Red;
				UpTrendColor = Brushes.Green;
			}
		}

		protected override void OnBarUpdate()
		{
			signal = 0;

			// Calculate up trend line
			int upTrendStartBarsAgo = 0;
			int upTrendEndBarsAgo = 0;
			int upTrendOccurence = 1;

			while (Low[upTrendEndBarsAgo] <= Low[upTrendStartBarsAgo])
			{
				upTrendStartBarsAgo = Swing(Strength).SwingLowBar(0, upTrendOccurence + 1, CurrentBar);
				upTrendEndBarsAgo = Swing(Strength).SwingLowBar(0, upTrendOccurence, CurrentBar);

				if (upTrendStartBarsAgo < 0 || upTrendEndBarsAgo < 0)
					break;

				upTrendOccurence++;
			}


			// Calculate down trend line	
			int downTrendStartBarsAgo = 0;
			int downTrendEndBarsAgo = 0;
			int downTrendOccurence = 1;

			while (High[downTrendEndBarsAgo] >= High[downTrendStartBarsAgo])
			{
				downTrendStartBarsAgo = Swing(Strength).SwingHighBar(0, downTrendOccurence + 1, CurrentBar);
				downTrendEndBarsAgo = Swing(Strength).SwingHighBar(0, downTrendOccurence, CurrentBar);

				if (downTrendStartBarsAgo < 0 || downTrendEndBarsAgo < 0)
					break;

				downTrendOccurence++;
			}


			// Always clear out arrows that mark trend line breaks
			RemoveDrawObject("DownTrendBreak");
			RemoveDrawObject("UpTrendBreak");


			// We have found an uptrend and the uptrend is the current trend
			if (upTrendStartBarsAgo > 0 && upTrendEndBarsAgo > 0 && upTrendStartBarsAgo < downTrendStartBarsAgo)
			{
				RemoveDrawObject("DownTrendLine");

				// Reset the alert if required
				if (triggerBarIndex != CurrentBar - upTrendEndBarsAgo)
				{
					triggerBarIndex = 0;
					RearmAlert("Alert");
				}

				double startBarPrice = Low[upTrendStartBarsAgo];
				double endBarPrice = Low[upTrendEndBarsAgo];
				double changePerBar = (endBarPrice - startBarPrice) / (Math.Abs(upTrendEndBarsAgo - upTrendStartBarsAgo));

				// Draw the up trend line
				Draw.Ray(this, "UpTrendLine", true, upTrendStartBarsAgo, startBarPrice, upTrendEndBarsAgo, endBarPrice, UpTrendColor, DashStyleHelper.Solid, LineWidth);

				// Check for an uptrend line break
				for (int barsAgo = upTrendEndBarsAgo - 1; barsAgo >= 0; barsAgo--)
				{
					if (Close[barsAgo] < endBarPrice + (Math.Abs(upTrendEndBarsAgo - barsAgo) * changePerBar))
					{
						Draw.ArrowDown(this, "UpTrendBreak", true, barsAgo, High[barsAgo] + TickSize, Brushes.Blue);

						// Set the signal only if the break is on the right most bar
						if (barsAgo == 0)
							signal = 2;

						// Alert will only trigger in real-time
						if (AlertOnBreak && triggerBarIndex == 0)
						{
							triggerBarIndex = CurrentBar - upTrendEndBarsAgo;
							Alert("Alert", Priority.High, "Up trend line broken", "Alert2.wav", 100000, Brushes.Black, Brushes.Red);
						}

						break;
					}
				}
			}
			// We have found a downtrend and the downtrend is the current trend
			else if (downTrendStartBarsAgo > 0 && downTrendEndBarsAgo > 0 && upTrendStartBarsAgo > downTrendStartBarsAgo)
			{
				RemoveDrawObject("UpTrendLine");

				// Reset the alert if required
				if (triggerBarIndex != CurrentBar - downTrendEndBarsAgo)
				{
					triggerBarIndex = 0;
					RearmAlert("Alert");
				}

				double startBarPrice = High[downTrendStartBarsAgo];
				double endBarPrice = High[downTrendEndBarsAgo];
				double changePerBar = (endBarPrice - startBarPrice) / (Math.Abs(downTrendEndBarsAgo - downTrendStartBarsAgo));

				// Draw the down trend line
				Draw.Ray(this, "DownTrendLine", true, downTrendStartBarsAgo, startBarPrice, downTrendEndBarsAgo, endBarPrice, DownTrendColor, DashStyleHelper.Solid, LineWidth);

				// Check for a down trend line break
				for (int barsAgo = downTrendEndBarsAgo - 1; barsAgo >= 0; barsAgo--)
				{
					if (Close[barsAgo] > endBarPrice + (Math.Abs(downTrendEndBarsAgo - barsAgo) * changePerBar))
					{
						Draw.ArrowUp(this, "DownTrendBreak", true, barsAgo, Low[barsAgo] - TickSize, Brushes.Blue);

						// Set the signal only if the break is on the right most bar
						if (barsAgo == 0)
							signal = 1;

						// Alert will only trigger in real-time
						if (AlertOnBreak && triggerBarIndex == 0)
						{
							triggerBarIndex = CurrentBar - downTrendEndBarsAgo;
							Alert("Alert", Priority.High, "Down trend line broken", "Alert2.wav", 100000, Brushes.Black, Brushes.Green);
						}

						break;
					}
				}
			}
		}

		#region Properties
		[NinjaScriptProperty]
		[Display(Name = "AlertOnBreak", Description = "Generates a visual and audible alert on a trend line break", Order = 1, GroupName = "Parameters")]
		public bool AlertOnBreak
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "Strength", Description = "Number of bars required on each side swing pivot points used to connect the trend lines", Order = 2, GroupName = "Parameters")]
		public int Strength
		{ get; set; }

		[NinjaScriptProperty]
		[Range(1, int.MaxValue)]
		[Display(Name = "LineWidth", Description = "Trend line width", Order = 3, GroupName = "Parameters")]
		public int LineWidth
		{ get; set; }

		[XmlIgnore]
		[Browsable(false)]
		[Range(1, int.MaxValue)]
		[Display(Name = "Signal", Order = 4, GroupName = "Parameters")]
		public int Signal
		{
			get { Update(); return signal; }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "DownTrendColor", Description = "Color of the down trend line.", Order = 5, GroupName = "Parameters")]
		public Brush DownTrendColor
		{ get; set; }

		[Browsable(false)]
		public string DownTrendColorSerializable
		{
			get { return Serialize.BrushToString(DownTrendColor); }
			set { DownTrendColor = Serialize.StringToBrush(value); }
		}

		[NinjaScriptProperty]
		[XmlIgnore]
		[Display(Name = "UpTrendColor", Description = "Color of the up trend line.", Order = 6, GroupName = "Parameters")]
		public Brush UpTrendColor
		{ get; set; }

		[Browsable(false)]
		public string UpTrendColorSerializable
		{
			get { return Serialize.BrushToString(UpTrendColor); }
			set { UpTrendColor = Serialize.StringToBrush(value); }
		}
		#endregion

	}
}

#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		private AutoTrendLine[] cacheAutoTrendLine;
		public AutoTrendLine AutoTrendLine(bool alertOnBreak, int strength, int lineWidth, Brush downTrendColor, Brush upTrendColor)
		{
			return AutoTrendLine(Input, alertOnBreak, strength, lineWidth, downTrendColor, upTrendColor);
		}

		public AutoTrendLine AutoTrendLine(ISeries<double> input, bool alertOnBreak, int strength, int lineWidth, Brush downTrendColor, Brush upTrendColor)
		{
			if (cacheAutoTrendLine != null)
				for (int idx = 0; idx < cacheAutoTrendLine.Length; idx++)
					if (cacheAutoTrendLine[idx] != null && cacheAutoTrendLine[idx].AlertOnBreak == alertOnBreak && cacheAutoTrendLine[idx].Strength == strength && cacheAutoTrendLine[idx].LineWidth == lineWidth && cacheAutoTrendLine[idx].DownTrendColor == downTrendColor && cacheAutoTrendLine[idx].UpTrendColor == upTrendColor && cacheAutoTrendLine[idx].EqualsInput(input))
						return cacheAutoTrendLine[idx];
			return CacheIndicator<AutoTrendLine>(new AutoTrendLine(){ AlertOnBreak = alertOnBreak, Strength = strength, LineWidth = lineWidth, DownTrendColor = downTrendColor, UpTrendColor = upTrendColor }, input, ref cacheAutoTrendLine);
		}
	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		public Indicators.AutoTrendLine AutoTrendLine(bool alertOnBreak, int strength, int lineWidth, Brush downTrendColor, Brush upTrendColor)
		{
			return indicator.AutoTrendLine(Input, alertOnBreak, strength, lineWidth, downTrendColor, upTrendColor);
		}

		public Indicators.AutoTrendLine AutoTrendLine(ISeries<double> input , bool alertOnBreak, int strength, int lineWidth, Brush downTrendColor, Brush upTrendColor)
		{
			return indicator.AutoTrendLine(input, alertOnBreak, strength, lineWidth, downTrendColor, upTrendColor);
		}
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		public Indicators.AutoTrendLine AutoTrendLine(bool alertOnBreak, int strength, int lineWidth, Brush downTrendColor, Brush upTrendColor)
		{
			return indicator.AutoTrendLine(Input, alertOnBreak, strength, lineWidth, downTrendColor, upTrendColor);
		}

		public Indicators.AutoTrendLine AutoTrendLine(ISeries<double> input , bool alertOnBreak, int strength, int lineWidth, Brush downTrendColor, Brush upTrendColor)
		{
			return indicator.AutoTrendLine(input, alertOnBreak, strength, lineWidth, downTrendColor, upTrendColor);
		}
	}
}

#endregion
